/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Test;

import FilesHandlers.ExcelHandler;
import java.io.*;
import java.util.Arrays;
import org.apache.poi.xssf.usermodel.*;

/**
 *
 * @author arikzil
 */
public class Tester {

    public static void main(String args[]) throws Exception {
        ExcelHandler excelHandler = new ExcelHandler("/home/arikzil/Desktop/dd/");

        System.out.println(Arrays.toString(excelHandler.getColByNum(0, "attempt.xlsx", 0)));
    }

}
